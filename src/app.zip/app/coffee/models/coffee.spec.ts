import { Coffee } from './coffee';

describe('Coffee', () => {
  it('should create an instance', () => {
    expect(new Coffee()).toBeTruthy();
  });
});
